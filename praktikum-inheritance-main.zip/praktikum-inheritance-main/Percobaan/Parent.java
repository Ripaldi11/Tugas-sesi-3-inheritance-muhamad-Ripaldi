package Percobaan;

public class Parent {
    public Parent() {
        // Konstruktor default kosong
    }
}

class Child extends Parent {
    int x;
    
    public Child() {
        x = 5;
    }
}
